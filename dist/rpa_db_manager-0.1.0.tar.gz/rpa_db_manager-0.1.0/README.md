# automation-database-manager
Python code to manage database integration with automations
